import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { GameState, GameAction, Superpower } from '../types';
import { initialCountries } from '../data/countries';
import { initialEvents } from '../data/events';

const initialState: GameState = {
  year: 1945,
  defcon: 5,
  selectedSuperpower: 'usa',
  superpowers: {
    usa: { military: 50, economy: 70, influence: 60 },
    ussr: { military: 70, economy: 40, influence: 50 }
  },
  countries: initialCountries,
  activeEvents: initialEvents.filter(event => event.year === 1945),
  resolvedEvents: [],
  spaceRace: { usa: 0, ussr: 0 },
  nuclearArsenal: { usa: 0, ussr: 0 },
  gameOver: false,
  gameOverReason: '',
  stability: 100,
  victorious: false
};

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'SELECT_SUPERPOWER':
      return {
        ...state,
        selectedSuperpower: action.payload as Superpower
      };

    case 'ADVANCE_YEAR': {
      const newYear = state.year + 1;
      const newEvents = initialEvents.filter(event => event.year === newYear);
      
      // Check for victory condition (reaching 1991)
      if (newYear > 1991) {
        const isVictorious = state.stability > 50 && state.defcon > 2;
        return {
          ...state,
          gameOver: true,
          victorious: isVictorious,
          gameOverReason: isVictorious 
            ? `Congratulations! You've successfully led your superpower through the Cold War era. Your strategic decisions helped maintain global stability and prevented nuclear conflict.`
            : `You've reached 1991, but your nation's position is too weak to claim victory. The Cold War ends with your adversary in a stronger position.`
        };
      }
      
      // Resource regeneration
      const updatedSuperpowers = { ...state.superpowers };
      ['usa', 'ussr'].forEach((power) => {
        const sp = power as Superpower;
        const controlledCountries = state.countries.filter(
          c => (sp === 'usa' && c.alignment > 30) || (sp === 'ussr' && c.alignment < -30)
        );
        
        updatedSuperpowers[sp] = {
          military: Math.min(100, updatedSuperpowers[sp].military + controlledCountries.length),
          economy: Math.min(100, updatedSuperpowers[sp].economy + controlledCountries.length * 2),
          influence: Math.min(100, updatedSuperpowers[sp].influence + controlledCountries.length)
        };
      });
      
      return {
        ...state,
        year: newYear,
        activeEvents: [...state.activeEvents.filter(e => !e.isResolved), ...newEvents],
        superpowers: updatedSuperpowers
      };
    }

    case 'MAKE_DECISION': {
      const { eventId, optionId } = action.payload;
      const updatedEvents = state.activeEvents.map(event => {
        if (event.id === eventId) {
          return { ...event, isResolved: true };
        }
        return event;
      });

      const resolvedEvent = state.activeEvents.find(e => e.id === eventId);
      const options = state.selectedSuperpower === 'usa' ? resolvedEvent?.usaOptions : resolvedEvent?.ussrOptions;
      const selectedOption = options?.find(opt => opt.id === optionId);
      
      if (selectedOption?.resourceCost) {
        const currentResources = state.superpowers[state.selectedSuperpower];
        for (const [resource, cost] of Object.entries(selectedOption.resourceCost)) {
          if (currentResources[resource as keyof typeof currentResources] < cost) {
            return {
              ...state,
              gameOver: true,
              victorious: false,
              gameOverReason: `Insufficient ${resource} to execute this action. Your government has collapsed due to resource mismanagement.`
            };
          }
        }
      }
      
      // Calculate stability impact from decision
      let stabilityChange = 0;
      selectedOption?.outcomes[0].effects.forEach(effect => {
        if (effect.type === 'stability') {
          // Positive stability changes are doubled to reward good decisions
          stabilityChange += effect.value as number > 0 
            ? (effect.value as number) * 2 
            : effect.value as number;
        }
      });
      
      const newStability = Math.max(0, Math.min(100, state.stability + stabilityChange));
      
      if (newStability <= 0) {
        return {
          ...state,
          gameOver: true,
          victorious: false,
          gameOverReason: 'Your decisions have led to a complete loss of stability and control.'
        };
      }
      
      return {
        ...state,
        activeEvents: updatedEvents.filter(e => !e.isResolved),
        resolvedEvents: resolvedEvent 
          ? [...state.resolvedEvents, {...resolvedEvent, isResolved: true}]
          : state.resolvedEvents,
        stability: newStability
      };
    }

    case 'UPDATE_RESOURCES': {
      const { superpower, resources } = action.payload;
      const updatedResources = {
        ...state.superpowers[superpower],
        ...resources
      };
      
      if (updatedResources.economy <= 0 || updatedResources.military <= 0) {
        return {
          ...state,
          gameOver: true,
          victorious: false,
          gameOverReason: updatedResources.economy <= 0
            ? 'Economic collapse has led to the fall of your government.'
            : 'Military weakness has left your nation vulnerable to invasion.'
        };
      }

      return {
        ...state,
        superpowers: {
          ...state.superpowers,
          [superpower]: updatedResources
        }
      };
    }

    case 'UPDATE_COUNTRY_ALIGNMENT': {
      const { countryId, change } = action.payload;
      const updatedCountries = state.countries.map(country => {
        if (country.id === countryId) {
          const newAlignment = Math.max(-100, Math.min(100, country.alignment + change));
          return { ...country, alignment: newAlignment };
        }
        return country;
      });

      return {
        ...state,
        countries: updatedCountries
      };
    }

    case 'UPDATE_DEFCON': {
      const newDefcon = Math.max(1, Math.min(5, state.defcon + action.payload));
      if (newDefcon === 1) {
        return {
          ...state,
          gameOver: true,
          victorious: false,
          gameOverReason: 'Nuclear war has broken out. There are no winners.'
        };
      }
      return {
        ...state,
        defcon: newDefcon
      };
    }

    case 'ADVANCE_SPACE_RACE': {
      const { superpower, steps } = action.payload;
      return {
        ...state,
        spaceRace: {
          ...state.spaceRace,
          [superpower]: Math.min(10, state.spaceRace[superpower] + steps)
        }
      };
    }

    case 'RESET_GAME':
      return initialState;

    default:
      return state;
  }
}

interface GameContextProps {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
}

const GameContext = createContext<GameContextProps | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
}