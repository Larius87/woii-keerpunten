import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Globe, ShieldAlert, Rocket, History } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  const { dispatch } = useGame();
  
  const handleSelectUSA = () => {
    dispatch({ type: 'SELECT_SUPERPOWER', payload: 'usa' });
    onStart();
  };
  
  const handleSelectUSSR = () => {
    dispatch({ type: 'SELECT_SUPERPOWER', payload: 'ussr' });
    onStart();
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white flex flex-col">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.pexels.com/photos/87651/earth-blue-planet-globe-planet-87651.jpeg')] bg-cover bg-center"></div>
      </div>
      
      <div className="container mx-auto flex-1 flex items-center justify-center px-4">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-10">
            <div className="flex justify-center mb-4">
              <Globe size={50} className="text-blue-400" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 tracking-tighter">
              <span className="text-blue-400">COLD</span> <span className="text-white">WAR</span> <span className="text-red-500">CRISIS</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Navigate the tensions between superpowers from 1945-1991 in this historical strategy game.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div className="bg-blue-900/40 backdrop-blur-sm rounded-lg p-6 border border-blue-800 hover:bg-blue-800/40 transition-all shadow-lg">
              <div className="flex items-center mb-4">
                <ShieldAlert size={24} className="text-blue-400 mr-3" />
                <h2 className="text-2xl font-bold text-blue-300">United States</h2>
              </div>
              <p className="text-gray-300 mb-6">
                Lead the United States with a focus on economic strength, technological innovation, and democratic alliances.
              </p>
              <button 
                onClick={handleSelectUSA}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded transition-colors"
              >
                Choose USA
              </button>
            </div>
            
            <div className="bg-red-900/40 backdrop-blur-sm rounded-lg p-6 border border-red-800 hover:bg-red-800/40 transition-all shadow-lg">
              <div className="flex items-center mb-4">
                <ShieldAlert size={24} className="text-red-400 mr-3" />
                <h2 className="text-2xl font-bold text-red-300">Soviet Union</h2>
              </div>
              <p className="text-gray-300 mb-6">
                Command the USSR with military might, communist ideology, and a network of satellite states.
              </p>
              <button 
                onClick={handleSelectUSSR}
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded transition-colors"
              >
                Choose USSR
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
            <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-lg text-center">
              <History size={24} className="text-yellow-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white">Historical Events</h3>
              <p className="text-sm text-gray-300">Face pivotal moments that shaped the Cold War era</p>
            </div>
            
            <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-lg text-center">
              <Globe size={24} className="text-green-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white">Global Strategy</h3>
              <p className="text-sm text-gray-300">Expand your influence across an interactive world map</p>
            </div>
            
            <div className="bg-gray-800/70 backdrop-blur-sm p-4 rounded-lg text-center">
              <Rocket size={24} className="text-purple-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white">Arms Race</h3>
              <p className="text-sm text-gray-300">Compete in nuclear weapons and space technology</p>
            </div>
          </div>
          
          <div className="text-center text-gray-400 text-sm">
            <p>Educational game based on Cold War history (1945-1991)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StartScreen;