import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import Header from '../components/Header';
import WorldMap from '../components/WorldMap';
import ResourcePanel from '../components/ResourcePanel';
import EventCard from '../components/EventCard';
import GameControls from '../components/GameControls';
import Timeline from '../components/Timeline';
import InfoPanel from '../components/InfoPanel';
import { Map, Trophy, XCircle } from 'lucide-react';

const GameBoard: React.FC = () => {
  const { state, dispatch } = useGame();
  const { activeEvents, gameOver, gameOverReason, victorious } = state;
  const [showMap, setShowMap] = useState(false);

  const handleAdvanceYear = () => {
    dispatch({ type: 'ADVANCE_YEAR', payload: null });
  };

  if (gameOver) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="bg-gray-800 p-8 rounded-lg max-w-lg text-center">
          <div className="flex justify-center mb-6">
            {victorious ? (
              <Trophy size={64} className="text-yellow-400" />
            ) : (
              <XCircle size={64} className="text-red-400" />
            )}
          </div>
          <h2 className={`text-2xl font-bold mb-4 ${victorious ? 'text-yellow-400' : 'text-red-400'}`}>
            {victorious ? 'Victory!' : 'Game Over'}
          </h2>
          <p className="text-gray-300 mb-6">{gameOverReason}</p>
          <button
            onClick={() => window.location.reload()}
            className={`${
              victorious ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-blue-600 hover:bg-blue-700'
            } text-white font-bold py-2 px-4 rounded`}
          >
            Start New Game
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left sidebar with resources and controls */}
          <div className="lg:col-span-1 space-y-6">
            <ResourcePanel superpower="usa" />
            <ResourcePanel superpower="ussr" />
            <GameControls />
            <InfoPanel />
          </div>
          
          {/* Main game area */}
          <div className="lg:col-span-3 space-y-6">
            <div className="flex justify-between items-center gap-4">
              <button
                onClick={() => setShowMap(!showMap)}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white font-bold py-3 px-4 rounded-lg border border-gray-700 transition-colors flex items-center justify-center gap-2"
              >
                <Map size={20} />
                {showMap ? 'Hide World Map' : 'Show World Map'}
              </button>
            </div>
            
            {showMap && (
              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <h2 className="text-2xl font-bold mb-4">World Map</h2>
                <div className="h-80 md:h-96">
                  <WorldMap />
                </div>
              </div>
            )}
            
            {activeEvents.length > 0 ? (
              <div>
                <h2 className="text-2xl font-bold mb-4">Current Events</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {activeEvents.map(event => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-gray-800 rounded-lg p-6 text-center border border-gray-700">
                <h3 className="text-xl font-bold mb-2">No Active Events</h3>
                <p className="text-gray-400">Advance to the next year to continue the game.</p>
              </div>
            )}
          </div>
          
          {/* Right sidebar with timeline and next year button */}
          <div className="lg:col-span-1 space-y-6">
            <button
              onClick={handleAdvanceYear}
              className="w-full bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-3 rounded-lg transition-all flex items-center justify-center gap-2 font-bold"
            >
              Next Year
            </button>
            <Timeline />
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-900 border-t border-gray-800 py-3 text-center text-gray-500 text-sm">
        <div className="container mx-auto">
          Cold War Crisis Game - Educational Simulation
        </div>
      </footer>
    </div>
  );
};

export default GameBoard;