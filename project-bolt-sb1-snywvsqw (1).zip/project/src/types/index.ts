export type Superpower = 'usa' | 'ussr';

export type ResourceType = 'military' | 'economy' | 'influence';

export interface Resources {
  military: number;
  economy: number;
  influence: number;
}

export interface Country {
  id: string;
  name: string;
  region: Region;
  alignment: number; // -100 (fully USSR) to 100 (fully USA)
  resources: Resources;
  importance: number; // 1-10 strategic importance
}

export interface Event {
  id: string;
  year: number;
  title: string;
  description: string;
  historicalContext?: string;
  affectedCountries: string[];
  usaOptions?: DecisionOption[];
  ussrOptions?: DecisionOption[];
  isActive: boolean;
  isResolved: boolean;
}

export interface DecisionOption {
  id: string;
  text: string;
  resourceCost: Partial<Resources>;
  outcomes: Outcome[];
}

export interface Outcome {
  probability: number; // 0-100%
  description: string;
  effects: Effect[];
}

export interface Effect {
  type: 'alignment' | 'resources' | 'event' | 'crisis' | 'defcon' | 'stability';
  target: string; // country id or 'player'
  value: number | string;
}

export type Region = 'northAmerica' | 'southAmerica' | 'europe' | 'africa' | 'middleEast' | 'asia' | 'oceania';

export interface GameState {
  year: number;
  defcon: number; // 5 (peace) to 1 (nuclear war)
  selectedSuperpower: Superpower;
  superpowers: Record<Superpower, Resources>;
  countries: Country[];
  activeEvents: Event[];
  resolvedEvents: Event[];
  spaceRace: Record<Superpower, number>; // progress level 0-10
  nuclearArsenal: Record<Superpower, number>;
  gameOver: boolean;
  gameOverReason: string;
  stability: number; // 0-100, represents how close to losing
  victorious: boolean;
}