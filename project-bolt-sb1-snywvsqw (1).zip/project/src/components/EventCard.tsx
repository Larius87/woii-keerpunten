import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Event } from '../types';
import { AlertCircle, Clock, Globe, Shield, DollarSign, Landmark } from 'lucide-react';

interface EventCardProps {
  event: Event;
}

const EventCard: React.FC<EventCardProps> = ({ event }) => {
  const { state, dispatch } = useGame();
  const { selectedSuperpower } = state;
  const [selectedOutcome, setSelectedOutcome] = useState<string | null>(null);
  
  const currentOptions = selectedSuperpower === 'usa' ? event.usaOptions : event.ussrOptions;
  const opposingOptions = selectedSuperpower === 'usa' ? event.ussrOptions : event.usaOptions;
  
  const handleDecision = (optionId: string) => {
    if (currentOptions) {
      const selectedOption = currentOptions.find(option => option.id === optionId);
      if (selectedOption) {
        setSelectedOutcome(selectedOption.outcomes[0].description);
        
        dispatch({
          type: 'MAKE_DECISION',
          payload: { eventId: event.id, optionId }
        });
        
        if (selectedOption.resourceCost) {
          dispatch({
            type: 'UPDATE_RESOURCES',
            payload: {
              superpower: selectedSuperpower,
              resources: Object.entries(selectedOption.resourceCost).reduce((acc, [key, value]) => {
                const resourceKey = key as keyof typeof selectedOption.resourceCost;
                return {
                  ...acc,
                  [resourceKey]: state.superpowers[selectedSuperpower][resourceKey] - (value as number)
                };
              }, {})
            }
          });
        }
        
        if (selectedOption.outcomes.length > 0) {
          const outcome = selectedOption.outcomes[0];
          outcome.effects.forEach(effect => {
            if (effect.type === 'alignment') {
              dispatch({
                type: 'UPDATE_COUNTRY_ALIGNMENT',
                payload: { countryId: effect.target, change: effect.value }
              });
            } else if (effect.type === 'defcon') {
              dispatch({
                type: 'UPDATE_DEFCON',
                payload: effect.value
              });
            }
          });
        }
      }
    }
  };

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl">
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-white">{event.title}</h3>
          <div className="flex items-center text-yellow-400 text-sm">
            <Clock size={16} className="mr-1" />
            <span>{event.year}</span>
          </div>
        </div>
        
        <p className="text-gray-300 mb-4">{event.description}</p>
        
        {event.historicalContext && (
          <div className="mb-4 p-2 bg-gray-700/50 rounded border-l-4 border-yellow-500">
            <div className="flex items-start">
              <AlertCircle size={18} className="text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-300 italic">{event.historicalContext}</p>
            </div>
          </div>
        )}
        
        <div className="mb-4">
          <div className="flex items-center text-sm text-gray-400 mb-2">
            <Globe size={16} className="mr-1" />
            <span>Affected regions:</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {event.affectedCountries.map(countryId => {
              const country = state.countries.find(c => c.id === countryId);
              return country ? (
                <span 
                  key={countryId}
                  className="px-2 py-1 text-xs rounded-full bg-gray-700 text-gray-300"
                >
                  {country.name}
                </span>
              ) : null;
            })}
          </div>
        </div>
        
        {selectedOutcome ? (
          <div className="space-y-4">
            <div className="p-4 bg-gray-700/50 rounded-lg border border-gray-600">
              <h4 className="text-lg font-semibold text-white mb-2">Your Outcome:</h4>
              <p className="text-gray-300">{selectedOutcome}</p>
            </div>
            
            <div className="p-4 bg-gray-700/50 rounded-lg border border-gray-600">
              <h4 className="text-lg font-semibold text-white mb-2">Opposing Options:</h4>
              <div className="space-y-2">
                {opposingOptions?.map(option => (
                  <div key={option.id} className="p-3 bg-gray-800 rounded">
                    <p className="font-medium text-gray-300">{option.text}</p>
                    <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
                      {option.resourceCost.military && (
                        <div className="flex items-center text-red-400">
                          <Shield size={14} className="mr-1" />
                          <span>-{option.resourceCost.military}</span>
                        </div>
                      )}
                      {option.resourceCost.economy && (
                        <div className="flex items-center text-green-400">
                          <DollarSign size={14} className="mr-1" />
                          <span>-{option.resourceCost.economy}</span>
                        </div>
                      )}
                      {option.resourceCost.influence && (
                        <div className="flex items-center text-blue-400">
                          <Landmark size={14} className="mr-1" />
                          <span>-{option.resourceCost.influence}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-4">
            <h4 className="text-white font-semibold mb-2">Your Options:</h4>
            <div className="space-y-3">
              {currentOptions?.map(option => (
                <button
                  key={option.id}
                  className="w-full text-left p-4 rounded bg-gray-700 hover:bg-gray-600 text-gray-200 transition-colors"
                  onClick={() => handleDecision(option.id)}
                >
                  <div className="font-medium mb-2">{option.text}</div>
                  <div className="grid grid-cols-3 gap-2">
                    {option.resourceCost.military && (
                      <div className="flex items-center text-red-400">
                        <Shield size={16} className="mr-1" />
                        <span>-{option.resourceCost.military}</span>
                      </div>
                    )}
                    {option.resourceCost.economy && (
                      <div className="flex items-center text-green-400">
                        <DollarSign size={16} className="mr-1" />
                        <span>-{option.resourceCost.economy}</span>
                      </div>
                    )}
                    {option.resourceCost.influence && (
                      <div className="flex items-center text-blue-400">
                        <Landmark size={16} className="mr-1" />
                        <span>-{option.resourceCost.influence}</span>
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EventCard;