import React from 'react';
import { useGame } from '../contexts/GameContext';
import { AlertTriangle, Globe, Hourglass, Activity } from 'lucide-react';

const Header: React.FC = () => {
  const { state } = useGame();
  
  const getDefconColor = () => {
    switch(state.defcon) {
      case 1: return 'text-red-600 bg-red-100';
      case 2: return 'text-red-500 bg-red-50';
      case 3: return 'text-yellow-600 bg-yellow-50';
      case 4: return 'text-yellow-500 bg-yellow-50';
      case 5: return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getDefconText = () => {
    switch(state.defcon) {
      case 1: return 'DEFCON 1 - NUCLEAR WAR IMMINENT';
      case 2: return 'DEFCON 2 - NEXT STEP TO NUCLEAR WAR';
      case 3: return 'DEFCON 3 - INCREASED READINESS';
      case 4: return 'DEFCON 4 - INCREASED INTELLIGENCE';
      case 5: return 'DEFCON 5 - NORMAL PEACETIME';
      default: return 'DEFCON UNKNOWN';
    }
  };

  const getStabilityColor = () => {
    if (state.stability > 75) return 'text-green-500';
    if (state.stability > 50) return 'text-yellow-500';
    if (state.stability > 25) return 'text-orange-500';
    return 'text-red-500';
  };

  return (
    <div className="px-4 py-3 bg-gradient-to-r from-gray-900 to-gray-800 text-white shadow-md">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-2 md:mb-0">
          <Globe className="h-6 w-6 mr-2 text-blue-400" />
          <h1 className="text-xl font-bold tracking-wider">COLD WAR CRISIS</h1>
        </div>
        
        <div className="flex flex-wrap justify-center gap-3 md:gap-6">
          <div className="flex items-center">
            <Hourglass className="h-5 w-5 mr-1 text-yellow-400" />
            <span className="font-mono font-semibold text-lg">{state.year}</span>
          </div>
          
          <div className={`flex items-center px-3 py-1 rounded-full ${getDefconColor()}`}>
            <AlertTriangle className="h-4 w-4 mr-1" />
            <span className="font-mono font-semibold text-sm">{getDefconText()}</span>
          </div>

          <div className="flex items-center gap-2">
            <Activity className={`h-5 w-5 ${getStabilityColor()}`} />
            <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${getStabilityColor()}`}
                style={{ width: `${state.stability}%` }}
              />
            </div>
            <span className="font-mono text-sm">{state.stability}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;