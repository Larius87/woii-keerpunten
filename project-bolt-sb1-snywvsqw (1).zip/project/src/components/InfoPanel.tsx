import React from 'react';
import { AlertCircle, HelpCircle } from 'lucide-react';

const InfoPanel: React.FC = () => {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
      <div className="flex items-start mb-3">
        <HelpCircle size={18} className="text-blue-400 mr-2 flex-shrink-0 mt-0.5" />
        <h3 className="text-white text-lg font-semibold">Game Guide</h3>
      </div>
      
      <div className="space-y-3 text-sm text-gray-300">
        <p>
          Navigate the perilous waters of the Cold War as either the United States or the Soviet Union.
        </p>
        
        <div className="bg-black/30 p-2 rounded">
          <div className="font-semibold text-white mb-1">Game Objectives:</div>
          <ul className="list-disc pl-5 space-y-1">
            <li>Expand your global influence</li>
            <li>Manage your resources wisely</li>
            <li>Respond to historical crises</li>
            <li>Avoid nuclear war (DEFCON 1)</li>
          </ul>
        </div>
        
        <div className="bg-black/30 p-2 rounded">
          <div className="font-semibold text-white mb-1">Resource Guide:</div>
          <ul className="list-disc pl-5 space-y-1">
            <li><span className="text-yellow-400 font-medium">Military</span> - Used for armed interventions and defense</li>
            <li><span className="text-green-400 font-medium">Economy</span> - Funds your operations and foreign aid</li>
            <li><span className="text-blue-400 font-medium">Influence</span> - Your diplomatic and cultural power</li>
          </ul>
        </div>
        
        <div className="flex items-start mt-2">
          <AlertCircle size={16} className="text-red-400 mr-2 flex-shrink-0 mt-0.5" />
          <p className="italic">Remember, every decision you make can have far-reaching consequences!</p>
        </div>
      </div>
    </div>
  );
};

export default InfoPanel;