import React from 'react';
import { useGame } from '../contexts/GameContext';

const WorldMap: React.FC = () => {
  const { state } = useGame();
  const { countries } = state;

  // Function to determine country color based on alignment
  const getCountryColor = (alignment: number) => {
    if (alignment > 70) return 'bg-blue-700';
    if (alignment > 30) return 'bg-blue-500';
    if (alignment > 10) return 'bg-blue-300';
    if (alignment < -70) return 'bg-red-700';
    if (alignment < -30) return 'bg-red-500';
    if (alignment < -10) return 'bg-red-300';
    return 'bg-gray-400'; // Neutral
  };

  return (
    <div className="relative w-full h-full bg-slate-800 rounded-lg overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        {/* Simplified world map grid */}
        <div className="w-full h-full grid grid-cols-12 grid-rows-8">
          {Array.from({ length: 96 }).map((_, i) => (
            <div key={i} className="border border-gray-700" />
          ))}
        </div>
      </div>

      {/* Country representations */}
      <div className="absolute inset-0 p-4">
        <div className="grid grid-cols-3 gap-2 md:grid-cols-5 lg:grid-cols-7">
          {countries.map((country) => (
            <div 
              key={country.id}
              className={`${getCountryColor(country.alignment)} rounded p-2 text-xs md:text-sm transition-all duration-500 hover:scale-105`}
            >
              <div className="font-bold text-white truncate">{country.name}</div>
              <div className="flex justify-between text-white/80">
                <span>M: {country.resources.military}</span>
                <span>E: {country.resources.economy}</span>
              </div>
              <div className="mt-1 h-1 bg-black/20 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${country.alignment > 0 ? 'bg-blue-300' : 'bg-red-300'}`}
                  style={{ 
                    width: `${Math.abs(country.alignment)}%`,
                    marginLeft: country.alignment < 0 ? '0' : 'auto',
                    marginRight: country.alignment > 0 ? '0' : 'auto'
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Enhanced Map legend */}
      <div className="absolute bottom-2 right-2 bg-black/50 p-3 rounded text-xs text-white">
        <div className="font-semibold mb-2 text-sm">Alignment Legend</div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1">
          {/* USA Aligned */}
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-700 mr-1"></div>
            <span>Strong USA (70+)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 mr-1"></div>
            <span>Moderate USA (30+)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-300 mr-1"></div>
            <span>Weak USA (10+)</span>
          </div>
          
          {/* USSR Aligned */}
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-700 mr-1"></div>
            <span>Strong USSR (-70+)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 mr-1"></div>
            <span>Moderate USSR (-30+)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-300 mr-1"></div>
            <span>Weak USSR (-10+)</span>
          </div>
          
          {/* Neutral */}
          <div className="flex items-center col-span-2 mt-1">
            <div className="w-3 h-3 bg-gray-400 mr-1"></div>
            <span>Neutral (-10 to 10)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorldMap;