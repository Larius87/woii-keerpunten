import React from 'react';
import { useGame } from '../contexts/GameContext';
import { LogIn, RotateCw, Hourglass } from 'lucide-react';
import { Superpower } from '../types';

const GameControls: React.FC = () => {
  const { state, dispatch } = useGame();
  
  const handleSuperpowerSelect = (superpower: Superpower) => {
    dispatch({
      type: 'SELECT_SUPERPOWER',
      payload: superpower
    });
  };
  
  const handleAdvanceYear = () => {
    dispatch({ type: 'ADVANCE_YEAR', payload: null });
  };
  
  const handleResetGame = () => {
    if (confirm('Are you sure you want to reset the game?')) {
      dispatch({ type: 'RESET_GAME', payload: null });
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
      <div className="mb-4">
        <h3 className="text-white text-lg font-semibold mb-2">Controls</h3>
        <div className="grid grid-cols-2 gap-2">
          <button
            className={`px-4 py-2 rounded transition-all ${
              state.selectedSuperpower === 'usa'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-blue-800'
            }`}
            onClick={() => handleSuperpowerSelect('usa')}
          >
            <div className="flex items-center justify-center">
              <span className="font-semibold">USA</span>
            </div>
          </button>
          
          <button
            className={`px-4 py-2 rounded transition-all ${
              state.selectedSuperpower === 'ussr'
                ? 'bg-red-600 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-red-800'
            }`}
            onClick={() => handleSuperpowerSelect('ussr')}
          >
            <div className="flex items-center justify-center">
              <span className="font-semibold">USSR</span>
            </div>
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        <button
          className="flex items-center justify-center bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded transition-all"
          onClick={handleAdvanceYear}
        >
          <Hourglass size={16} className="mr-2" />
          <span>Next Year</span>
        </button>
        
        <button
          className="flex items-center justify-center bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded transition-all"
          onClick={handleResetGame}
        >
          <RotateCw size={16} className="mr-2" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
};

export default GameControls;