import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { initialEvents } from '../data/events';
import { CalendarDays, ChevronDown, ChevronUp } from 'lucide-react';

const Timeline: React.FC = () => {
  const { state } = useGame();
  const [expanded, setExpanded] = useState(false);
  
  // Get all unique years from the events list
  const years = Array.from(new Set(initialEvents.map(event => event.year))).sort();
  
  // Create a map of years to events
  const eventsByYear = years.reduce((acc, year) => {
    acc[year] = initialEvents.filter(event => event.year === year);
    return acc;
  }, {} as Record<number, typeof initialEvents>);
  
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg overflow-hidden">
      <div 
        className="bg-gray-700 px-4 py-3 flex justify-between items-center cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center">
          <CalendarDays size={18} className="text-yellow-400 mr-2" />
          <h3 className="text-white font-semibold">Historical Timeline</h3>
        </div>
        <button className="text-gray-400 hover:text-white transition-colors">
          {expanded ? (
            <ChevronUp size={18} />
          ) : (
            <ChevronDown size={18} />
          )}
        </button>
      </div>
      
      {expanded && (
        <div className="p-4 max-h-72 overflow-y-auto">
          <div className="relative">
            <div className="absolute top-0 bottom-0 left-4 w-0.5 bg-gray-600"></div>
            
            {years.map(year => (
              <div key={year} className="mb-4 relative">
                <div className="flex items-center mb-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${year <= state.year ? 'bg-yellow-400' : 'bg-gray-500'} z-10 -ml-1`}></div>
                  <div className={`ml-4 text-sm font-semibold ${year <= state.year ? 'text-yellow-400' : 'text-gray-500'}`}>
                    {year}
                  </div>
                </div>
                
                <div className="ml-8 space-y-2">
                  {eventsByYear[year].map(event => (
                    <div 
                      key={event.id}
                      className={`p-2 rounded text-sm transition-colors ${
                        state.resolvedEvents.find(e => e.id === event.id)
                          ? 'bg-gray-700/50 text-gray-400'
                          : year <= state.year
                            ? 'bg-gray-700 text-white'
                            : 'bg-gray-800 text-gray-500'
                      }`}
                    >
                      {event.title}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Timeline;