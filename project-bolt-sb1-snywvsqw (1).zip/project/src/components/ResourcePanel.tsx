import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Shield, DollarSign, Landmark, Rocket, Radiation } from 'lucide-react';
import { Superpower } from '../types';

interface ResourcePanelProps {
  superpower: Superpower;
}

const ResourcePanel: React.FC<ResourcePanelProps> = ({ superpower }) => {
  const { state } = useGame();
  const resources = state.superpowers[superpower];
  const spaceProgress = state.spaceRace[superpower];
  const nuclearCount = state.nuclearArsenal[superpower];
  
  const isActive = state.selectedSuperpower === superpower;
  const superpowerName = superpower === 'usa' ? 'United States' : 'Soviet Union';
  const baseClasses = "rounded-lg transition-all duration-300";
  const activeClasses = isActive 
    ? `${superpower === 'usa' ? 'bg-blue-900/80' : 'bg-red-900/80'} shadow-lg` 
    : 'bg-gray-800/60 opacity-50';

  return (
    <div className={`${baseClasses} ${activeClasses} p-4`}>
      <h3 className="text-xl font-bold text-center mb-4 text-white">
        {superpowerName}
      </h3>
      
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-black/30 p-2 rounded text-white">
          <div className="flex items-center">
            <Shield size={18} className="mr-2 text-yellow-400" />
            <span className="font-medium">Military</span>
          </div>
          <div className="mt-1 text-xl font-bold">{resources.military}</div>
        </div>
        
        <div className="bg-black/30 p-2 rounded text-white">
          <div className="flex items-center">
            <DollarSign size={18} className="mr-2 text-green-400" />
            <span className="font-medium">Economy</span>
          </div>
          <div className="mt-1 text-xl font-bold">{resources.economy}</div>
        </div>
        
        <div className="bg-black/30 p-2 rounded text-white">
          <div className="flex items-center">
            <Landmark size={18} className="mr-2 text-blue-400" />
            <span className="font-medium">Influence</span>
          </div>
          <div className="mt-1 text-xl font-bold">{resources.influence}</div>
        </div>
        
        <div className="bg-black/30 p-2 rounded text-white">
          <div className="flex items-center">
            <Rocket size={18} className="mr-2 text-purple-400" />
            <span className="font-medium">Space</span>
          </div>
          <div className="mt-1 text-xl font-bold">{spaceProgress}/10</div>
        </div>
      </div>
      
      <div className="mt-3 bg-black/30 p-2 rounded text-white">
        <div className="flex items-center">
          <Radiation size={18} className="mr-2 text-red-400" />
          <span className="font-medium">Nuclear Arsenal</span>
        </div>
        <div className="mt-1 text-xl font-bold">{nuclearCount}</div>
      </div>
    </div>
  );
};

export default ResourcePanel;