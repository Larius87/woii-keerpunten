import { Event } from '../types';

export const initialEvents: Event[] = [
  {
    id: 'potsdam-conference',
    year: 1945,
    title: 'Potsdam Conference',
    description: 'The leaders of the United States, Soviet Union, and United Kingdom meet to decide the future of post-war Germany and Europe.',
    historicalContext: 'This conference set the stage for the division of Germany and the growing mistrust between former allies.',
    affectedCountries: ['usa', 'ussr', 'uk', 'westGermany', 'eastGermany'],
    usaOptions: [
      {
        id: 'usa-cooperate',
        text: 'Propose cooperative administration of Germany',
        resourceCost: { influence: 5 },
        outcomes: [
          {
            probability: 100,
            description: 'The proposal is met with skepticism by the Soviet Union, but shows American willingness to cooperate.',
            effects: [
              { type: 'alignment', target: 'uk', value: 5 },
              { type: 'alignment', target: 'ussr', value: -5 }
            ]
          }
        ]
      },
      {
        id: 'usa-firm-stance',
        text: 'Take a firm stance against Soviet expansion',
        resourceCost: { military: 5, influence: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'The United States establishes itself as a counterbalance to Soviet influence in Europe.',
            effects: [
              { type: 'alignment', target: 'westGermany', value: 10 },
              { type: 'alignment', target: 'france', value: 5 },
              { type: 'alignment', target: 'ussr', value: -10 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-demand-reparations',
        text: 'Demand heavy reparations from Germany',
        resourceCost: { influence: 5 },
        outcomes: [
          {
            probability: 100,
            description: 'The Soviet Union secures economic benefits but increases tensions with Western allies.',
            effects: [
              { type: 'resources', target: 'ussr', value: 10 },
              { type: 'alignment', target: 'usa', value: -10 },
              { type: 'alignment', target: 'uk', value: -5 }
            ]
          }
        ]
      },
      {
        id: 'ussr-secure-east-europe',
        text: 'Focus on securing Soviet influence in Eastern Europe',
        resourceCost: { military: 10, influence: 5 },
        outcomes: [
          {
            probability: 100,
            description: 'The Soviet Union establishes firm control over Eastern Europe, creating a buffer zone.',
            effects: [
              { type: 'alignment', target: 'poland', value: -20 },
              { type: 'alignment', target: 'eastGermany', value: -15 },
              { type: 'alignment', target: 'usa', value: -15 }
            ]
          }
        ]
      }
    ],
    isActive: true,
    isResolved: false
  },
  {
    id: 'truman-doctrine',
    year: 1947,
    title: 'Truman Doctrine',
    description: 'President Truman announces US policy to contain Soviet expansion by supporting "free peoples" resisting subjugation.',
    historicalContext: 'The doctrine marked a significant hardening of US policy toward the Soviet Union and formalized the policy of containment.',
    affectedCountries: ['usa', 'ussr', 'greece', 'turkey'],
    usaOptions: [
      {
        id: 'usa-financial-aid',
        text: 'Provide financial aid to Greece and Turkey',
        resourceCost: { economy: 15, influence: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'Aid package strengthens democratic forces and prevents communist takeover.',
            effects: [
              { type: 'alignment', target: 'greece', value: 20 },
              { type: 'alignment', target: 'turkey', value: 20 },
              { type: 'alignment', target: 'ussr', value: -15 }
            ]
          }
        ]
      },
      {
        id: 'usa-military-advisors',
        text: 'Send military advisors and equipment',
        resourceCost: { military: 20, economy: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'Military support bolsters anti-communist forces but risks escalation.',
            effects: [
              { type: 'alignment', target: 'greece', value: 25 },
              { type: 'alignment', target: 'turkey', value: 25 },
              { type: 'alignment', target: 'ussr', value: -20 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-counter-propaganda',
        text: 'Launch counter-propaganda campaign',
        resourceCost: { influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'Soviet propaganda portrays American actions as imperialist intervention.',
            effects: [
              { type: 'alignment', target: 'greece', value: -5 },
              { type: 'alignment', target: 'turkey', value: -5 },
              { type: 'alignment', target: 'usa', value: -10 }
            ]
          }
        ]
      },
      {
        id: 'ussr-support-rebels',
        text: 'Covertly support communist rebels',
        resourceCost: { military: 10, influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'Soviet support keeps communist insurgency alive despite American aid.',
            effects: [
              { type: 'alignment', target: 'greece', value: -10 },
              { type: 'alignment', target: 'turkey', value: -5 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  },
  {
    id: 'berlin-blockade',
    year: 1948,
    title: 'Berlin Blockade',
    description: 'The Soviet Union blocks all land access to the Western-controlled sectors of Berlin.',
    historicalContext: 'This was the first major crisis of the Cold War, testing Western resolve to maintain presence in Berlin.',
    affectedCountries: ['usa', 'ussr', 'uk', 'france', 'westGermany', 'eastGermany'],
    usaOptions: [
      {
        id: 'usa-airlift',
        text: 'Implement Berlin Airlift to supply the city',
        resourceCost: { economy: 20, military: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'The massive airlift operation successfully supplies West Berlin, demonstrating Western resolve.',
            effects: [
              { type: 'alignment', target: 'westGermany', value: 20 },
              { type: 'alignment', target: 'uk', value: 10 },
              { type: 'alignment', target: 'france', value: 10 },
              { type: 'alignment', target: 'ussr', value: -15 }
            ]
          }
        ]
      },
      {
        id: 'usa-military-convoy',
        text: 'Force military convoy through the blockade',
        resourceCost: { military: 25, influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'The risky operation could lead to direct confrontation with Soviet forces.',
            effects: [
              { type: 'alignment', target: 'westGermany', value: 15 },
              { type: 'alignment', target: 'ussr', value: -25 },
              { type: 'defcon', target: 'global', value: -2 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-maintain-blockade',
        text: 'Maintain the blockade',
        resourceCost: { economy: 5, influence: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'The continued blockade tests Western resolve but damages Soviet reputation.',
            effects: [
              { type: 'alignment', target: 'eastGermany', value: -10 },
              { type: 'alignment', target: 'westGermany', value: -15 },
              { type: 'alignment', target: 'usa', value: -20 }
            ]
          }
        ]
      },
      {
        id: 'ussr-end-blockade',
        text: 'End the blockade in exchange for concessions',
        resourceCost: { influence: 20 },
        outcomes: [
          {
            probability: 100,
            description: 'The Soviet Union saves face by negotiating an end to the crisis.',
            effects: [
              { type: 'alignment', target: 'usa', value: 5 },
              { type: 'alignment', target: 'uk', value: 5 },
              { type: 'defcon', target: 'global', value: 1 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  },
  {
    id: 'cuban-missile-crisis',
    year: 1962,
    title: 'Cuban Missile Crisis',
    description: 'Soviet nuclear missiles discovered in Cuba, bringing the world to the brink of nuclear war.',
    historicalContext: 'This was the closest the Cold War came to escalating into a full-scale nuclear war.',
    affectedCountries: ['usa', 'ussr', 'cuba'],
    usaOptions: [
      {
        id: 'usa-blockade',
        text: 'Establish naval blockade of Cuba',
        resourceCost: { military: 20, influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'The "quarantine" prevents additional weapons from reaching Cuba while avoiding immediate military confrontation.',
            effects: [
              { type: 'alignment', target: 'uk', value: 10 },
              { type: 'alignment', target: 'ussr', value: -15 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      },
      {
        id: 'usa-airstrike',
        text: 'Launch airstrike against missile sites',
        resourceCost: { military: 30, influence: 20 },
        outcomes: [
          {
            probability: 100,
            description: 'Military action destroys missile sites but risks full-scale war with the Soviet Union.',
            effects: [
              { type: 'alignment', target: 'cuba', value: -30 },
              { type: 'alignment', target: 'ussr', value: -40 },
              { type: 'defcon', target: 'global', value: -3 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-withdraw-missiles',
        text: 'Withdraw missiles in exchange for US concessions',
        resourceCost: { influence: 25, military: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'The Soviet Union secures promise that US will not invade Cuba and will remove missiles from Turkey.',
            effects: [
              { type: 'alignment', target: 'cuba', value: -10 },
              { type: 'alignment', target: 'usa', value: 15 },
              { type: 'defcon', target: 'global', value: 2 }
            ]
          }
        ]
      },
      {
        id: 'ussr-maintain-missiles',
        text: 'Refuse to remove missiles and challenge blockade',
        resourceCost: { military: 30, influence: 20 },
        outcomes: [
          {
            probability: 100,
            description: 'Soviet ships attempt to break through the US naval blockade, risking direct military confrontation.',
            effects: [
              { type: 'alignment', target: 'cuba', value: 20 },
              { type: 'alignment', target: 'usa', value: -40 },
              { type: 'defcon', target: 'global', value: -3 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  },
  {
    id: 'vietnam-war',
    year: 1965,
    title: 'Vietnam War Escalation',
    description: 'The conflict in Vietnam intensifies as the United States considers increasing its military involvement.',
    historicalContext: 'The Vietnam War became a crucial proxy conflict between the superpowers, testing American military doctrine of containment.',
    affectedCountries: ['usa', 'ussr', 'vietnam'],
    usaOptions: [
      {
        id: 'usa-full-deployment',
        text: 'Launch full-scale military deployment',
        resourceCost: { military: 25, economy: 20 },
        outcomes: [
          {
            probability: 100,
            description: 'American forces engage in a costly but determined effort to support South Vietnam.',
            effects: [
              { type: 'alignment', target: 'vietnam', value: 20 },
              { type: 'stability', target: 'usa', value: -10 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      },
      {
        id: 'usa-limited-support',
        text: 'Provide limited military support and advisors',
        resourceCost: { military: 15, economy: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'A measured approach maintains support while limiting casualties.',
            effects: [
              { type: 'alignment', target: 'vietnam', value: 10 },
              { type: 'stability', target: 'usa', value: 5 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-aid-vietnam',
        text: 'Supply North Vietnam with military aid',
        resourceCost: { military: 15, economy: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'Soviet support strengthens North Vietnamese forces.',
            effects: [
              { type: 'alignment', target: 'vietnam', value: -20 },
              { type: 'stability', target: 'ussr', value: 10 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  },
  {
    id: 'prague-spring',
    year: 1968,
    title: 'Prague Spring',
    description: 'Reform movement in Czechoslovakia threatens Soviet control over Eastern Europe.',
    historicalContext: 'The Prague Spring represented a significant challenge to Soviet authority in the Eastern Bloc.',
    affectedCountries: ['ussr', 'czechoslovakia'],
    usaOptions: [
      {
        id: 'usa-diplomatic-support',
        text: 'Offer diplomatic support to reformers',
        resourceCost: { influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'American support encourages reform movement but risks Soviet reaction.',
            effects: [
              { type: 'alignment', target: 'czechoslovakia', value: 15 },
              { type: 'stability', target: 'usa', value: 5 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-military-intervention',
        text: 'Launch military intervention',
        resourceCost: { military: 20, influence: 15 },
        outcomes: [
          {
            probability: 100,
            description: 'Warsaw Pact forces restore Soviet control but damage international reputation.',
            effects: [
              { type: 'alignment', target: 'czechoslovakia', value: -30 },
              { type: 'stability', target: 'ussr', value: -5 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  },
  {
    id: 'afghan-war',
    year: 1979,
    title: 'Soviet-Afghan War',
    description: 'The Soviet Union considers military intervention in Afghanistan.',
    historicalContext: 'The Soviet-Afghan War became a costly military engagement that contributed to the USSR\'s eventual collapse.',
    affectedCountries: ['ussr', 'afghanistan'],
    usaOptions: [
      {
        id: 'usa-support-mujahideen',
        text: 'Support Afghan resistance fighters',
        resourceCost: { military: 15, influence: 10 },
        outcomes: [
          {
            probability: 100,
            description: 'American support helps Mujahideen resist Soviet forces.',
            effects: [
              { type: 'alignment', target: 'afghanistan', value: 20 },
              { type: 'stability', target: 'usa', value: 10 }
            ]
          }
        ]
      }
    ],
    ussrOptions: [
      {
        id: 'ussr-invade',
        text: 'Launch full invasion',
        resourceCost: { military: 25, economy: 20 },
        outcomes: [
          {
            probability: 100,
            description: 'Soviet forces become entangled in a difficult guerrilla war.',
            effects: [
              { type: 'alignment', target: 'afghanistan', value: -15 },
              { type: 'stability', target: 'ussr', value: -15 },
              { type: 'defcon', target: 'global', value: -1 }
            ]
          }
        ]
      }
    ],
    isActive: false,
    isResolved: false
  }
];