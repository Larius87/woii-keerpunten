import { Country } from '../types';

export const initialCountries: Country[] = [
  // North America
  {
    id: 'usa',
    name: 'United States',
    region: 'northAmerica',
    alignment: 100,
    resources: { military: 70, economy: 80, influence: 70 },
    importance: 10
  },

  // Europe
  {
    id: 'uk',
    name: 'United Kingdom',
    region: 'europe',
    alignment: 90,
    resources: { military: 60, economy: 60, influence: 70 },
    importance: 9
  },
  {
    id: 'france',
    name: 'France',
    region: 'europe',
    alignment: 70,
    resources: { military: 50, economy: 50, influence: 60 },
    importance: 8
  },
  {
    id: 'westGermany',
    name: 'West Germany',
    region: 'europe',
    alignment: 80,
    resources: { military: 40, economy: 60, influence: 50 },
    importance: 9
  },
  {
    id: 'eastGermany',
    name: 'East Germany',
    region: 'europe',
    alignment: -80,
    resources: { military: 40, economy: 30, influence: 30 },
    importance: 8
  },
  {
    id: 'ussr',
    name: 'Soviet Union',
    region: 'europe',
    alignment: -100,
    resources: { military: 80, economy: 60, influence: 70 },
    importance: 10
  },
  {
    id: 'poland',
    name: 'Poland',
    region: 'europe',
    alignment: -70,
    resources: { military: 30, economy: 20, influence: 20 },
    importance: 7
  },

  // Asia
  {
    id: 'china',
    name: 'China',
    region: 'asia',
    alignment: -60,
    resources: { military: 60, economy: 40, influence: 50 },
    importance: 9
  },
  {
    id: 'northKorea',
    name: 'North Korea',
    region: 'asia',
    alignment: -90,
    resources: { military: 30, economy: 10, influence: 10 },
    importance: 7
  },
  {
    id: 'southKorea',
    name: 'South Korea',
    region: 'asia',
    alignment: 80,
    resources: { military: 30, economy: 30, influence: 20 },
    importance: 7
  },
  {
    id: 'vietnam',
    name: 'Vietnam',
    region: 'asia',
    alignment: -30,
    resources: { military: 20, economy: 10, influence: 10 },
    importance: 7
  },
  
  // Caribbean
  {
    id: 'cuba',
    name: 'Cuba',
    region: 'southAmerica',
    alignment: -80,
    resources: { military: 20, economy: 20, influence: 30 },
    importance: 8
  }
];