import React, { useState } from 'react';
import { GameProvider } from './contexts/GameContext';
import StartScreen from './pages/StartScreen';
import GameBoard from './pages/GameBoard';

function App() {
  const [gameStarted, setGameStarted] = useState(false);
  
  const handleStartGame = () => {
    setGameStarted(true);
  };

  return (
    <GameProvider>
      <div className="min-h-screen bg-gray-900">
        {gameStarted ? (
          <GameBoard />
        ) : (
          <StartScreen onStart={handleStartGame} />
        )}
      </div>
    </GameProvider>
  );
}

export default App;